setting = {
    "account": "17343181597",  # 账号
    "password": "WHN20020318",  # 密码
    "sign": {
        "long": "161",  # 经度
        "lat": "40",  # 纬度
        "address": "",  # 地址
        "name": "王浩楠",  # 姓名
        "img": "https://images.cnblogs.com/cnblogs_com/blogs/734424/galleries/2119050/o_220330152155_sign.jpg",  # 图片打卡
        "sign_common": 1,   # 普通签到开1关0
        "sign_pic": 1,  # 拍照签到开1关0
        "sign_hand": 1,  # 手势签到开1关0
        "sign_local": 1  # 定位签到开1关0
    },
    "other": {
        "count": 5
    }
}

mail = {
    "email": "2809551464@qq.com",  # 接收邮件的邮箱
    "mail_host": "smtp.126.com",  # 发送邮件的邮箱服务器
    "mail_user": "morningstarts@126.com",  # 发送邮件的邮箱账号
    "mail_password": "WAFZMSRCNNBAQEUA"  # 发送邮件的邮箱密码
}
server = {
    "SCKEY": "SCT133949TgxZPE3LNMbmO3SmoeeuhJzxc"  # server酱的key
}
dingding = {
    "dingding_hook": "https://oapi.dingtalk.com/robot/send?access_token=517e9a58af7e113bcd92eedb87ef2cfa2e5adfd10ab3b52eae5ef30577768285"  # 钉钉机器人的hook
}
