setting = {
    "account": "",  # 账号
    "password": "",  # 密码
    "sign": {
        "long": "",  # 经度
        "lat": "",  # 纬度
        "address": "",  # 地址
        "name": "",  # 姓名
        "img": "",  # 图片打卡
        "sign_common": 1,   # 普通签到开1关0
        "sign_pic": 1,  # 拍照签到开1关0
        "sign_hand": 1,  # 手势签到开1关0
        "sign_local": 1  # 定位签到开1关0
    },
    "other": {
        "count": 5
    }
}

mail = {
    "email": "",  # 接收邮件的邮箱
    "mail_host": "",  # 发送邮件的邮箱服务器
    "mail_user": "",  # 发送邮件的邮箱账号
    "mail_password": ""  # 发送邮件的邮箱密码
}
server = {
    "SCKEY": ""  # server酱的key
}
dingding = {
    "dingding_hook": ""  # 钉钉机器人的hook
}
